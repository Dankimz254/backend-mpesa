# Flex Accounts M-Pesa Callback Backend

## Deploy on Render

1. Extract this ZIP file.
2. Upload the extracted project files to a GitHub repository.
3. In Render, choose **New + → Web Service** and connect the repository.
4. Use:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
5. Deploy the service.

Render will provide a public URL, for example:
`https://your-service-name.onrender.com`

Your Safaricom callback URL will be:
`https://your-service-name.onrender.com/api/mpesa/callback`

Use that callback URL as the `CallBackURL` in your STK Push request.

## Test the backend

Open the Render service URL in a browser. You should see:
`Flex Accounts M-Pesa callback backend is running.`

## Important

- This project only receives and logs STK Push callback results. It does not initiate STK Push payments.
- It does not save payment records permanently or automatically activate customer accounts.
- Add a persistent database and verify a callback against the original CheckoutRequestID before granting paid access.
- Do not put M-Pesa consumer secrets or passkeys in this project or in GitHub.
