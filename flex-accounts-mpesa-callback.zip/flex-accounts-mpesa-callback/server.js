const express = require("express");
const app = express();

app.use(express.json());

// Health check: open your Render URL to confirm the backend is running.
app.get("/", (req, res) => {
  res.status(200).send("Flex Accounts M-Pesa callback backend is running.");
});

// Safaricom Daraja STK Push callback endpoint.
app.post("/api/mpesa/callback", (req, res) => {
  try {
    const callback = req.body?.Body?.stkCallback;

    if (!callback) {
      console.error("Invalid callback received:", req.body);
      return res.status(200).json({
        ResultCode: 0,
        ResultDesc: "Callback received"
      });
    }

    const checkoutRequestID = callback.CheckoutRequestID;
    const resultCode = callback.ResultCode;
    const resultDesc = callback.ResultDesc;

    let paymentDetails = {};

    if (resultCode === 0) {
      const items = callback.CallbackMetadata?.Item || [];

      for (const item of items) {
        paymentDetails[item.Name] = item.Value;
      }

      console.log("PAYMENT SUCCESSFUL");
      console.log("Checkout ID:", checkoutRequestID);
      console.log("Amount:", paymentDetails.Amount);
      console.log("M-Pesa Receipt:", paymentDetails.MpesaReceiptNumber);
      console.log("Phone:", paymentDetails.PhoneNumber);
      console.log("Transaction Date:", paymentDetails.TransactionDate);

      // TODO: Save the successful payment in a persistent database.
      // Match it to the original STK Push using checkoutRequestID.
    } else {
      console.log("PAYMENT FAILED");
      console.log("Checkout ID:", checkoutRequestID);
      console.log("Reason:", resultDesc);

      // TODO: Save the failed/cancelled payment in your database.
    }

    return res.status(200).json({
      ResultCode: 0,
      ResultDesc: "Callback received successfully"
    });

  } catch (error) {
    console.error("Callback error:", error);

    // Acknowledge the callback to avoid repeated delivery.
    return res.status(200).json({
      ResultCode: 0,
      ResultDesc: "Callback received"
    });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Flex Accounts callback backend listening on port ${PORT}`);
});
